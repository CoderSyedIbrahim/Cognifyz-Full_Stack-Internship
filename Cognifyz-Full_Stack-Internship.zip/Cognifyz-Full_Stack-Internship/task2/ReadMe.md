# Task 2 -  Complex Form Validation and Dynamic DOM Manipulation
## Level - Intermediate
## Objective of the task
⚡️Enhance form validation to include more complex rules <br/>
⚡️Dynamically update the DOM based on user interactions using JavaScript. <br/>
⚡️Implement client-side routing for a smoother user experience
### [Live Preview](https://bhs-harish.github.io/Cognifyz-Full-Stack-Internship/task2)
